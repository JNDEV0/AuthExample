import React, { useState } from 'react';
import { WebAppLanding } from './components/WebAppLanding';
import { CloudflareInterstitial } from './components/CloudflareInterstitial';
import { AuthServer } from './components/AuthServer';
import { WebAppProtected } from './components/WebAppProtected';
import { AppStage, UserSession } from './types';

export default function App() {
  const [stage, setStage] = useState<AppStage>(AppStage.WEBAPP_LANDING);
  const [session, setSession] = useState<UserSession | null>(null);

  // Step 1: User clicks login on WebApp
  const handleInitiateLogin = () => {
    // Redirects to AuthServer, but intercepted by Cloudflare
    setStage(AppStage.CLOUDFLARE_INTERSTITIAL);
  };

  // Step 2: Cloudflare validated
  const handleCloudflareSuccess = () => {
    // Redirect to /connect/authorize on AuthServer
    setStage(AppStage.AUTH_SERVER);
  };

  // Step 3-7: Authentication Success
  const handleAuthenticated = (email: string) => {
    // Create session
    const newSession: UserSession = {
      email,
      claims: [
        `sub:${Math.random().toString(36).substring(7)}`,
        `email:${email}`,
        `role:User`,
        `auth_time:${Math.floor(Date.now() / 1000)}`
      ],
      accessToken: "eyJhbGciOiJIUzI1Ni..."
    };
    setSession(newSession);
    // Redirect back to WebApp Protected Area
    setStage(AppStage.WEBAPP_PROTECTED);
  };

  // Step 9: Logout
  const handleLogout = () => {
    setSession(null);
    // Real flow: Redirect to AuthServer end_session -> Redirect back to Home
    // We simulate this by going back to landing
    setTimeout(() => {
        setStage(AppStage.WEBAPP_LANDING);
    }, 500);
  };

  return (
    <>
      {stage === AppStage.WEBAPP_LANDING && (
        <WebAppLanding onLogin={handleInitiateLogin} />
      )}
      
      {stage === AppStage.CLOUDFLARE_INTERSTITIAL && (
        <CloudflareInterstitial onSuccess={handleCloudflareSuccess} />
      )}
      
      {stage === AppStage.AUTH_SERVER && (
        <AuthServer onAuthenticated={handleAuthenticated} />
      )}
      
      {stage === AppStage.WEBAPP_PROTECTED && session && (
        <WebAppProtected session={session} onLogout={handleLogout} />
      )}
    </>
  );
}