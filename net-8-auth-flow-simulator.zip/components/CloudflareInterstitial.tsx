import React, { useState, useEffect } from 'react';
import { ShieldCheck, Loader2 } from 'lucide-react';

interface Props {
  onSuccess: () => void;
}

export const CloudflareInterstitial: React.FC<Props> = ({ onSuccess }) => {
  const [status, setStatus] = useState<'waiting' | 'verifying' | 'success'>('waiting');
  const [rayId, setRayId] = useState('');

  useEffect(() => {
    // Generate a random Ray ID similar to Cloudflare's format
    const randomHex = Array.from({ length: 16 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    setRayId(randomHex);
  }, []);

  const handleVerify = () => {
    setStatus('verifying');
    setTimeout(() => {
      setStatus('success');
      setTimeout(onSuccess, 800); // Slight delay before redirect
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-4 text-gray-800 font-sans">
      <div className="max-w-md w-full space-y-8">
        <div className="flex items-center gap-3">
          <h1 className="text-3xl font-semibold">WebApp</h1>
        </div>
        
        <div className="border border-gray-200 bg-gray-50 p-6 rounded-lg shadow-sm">
          <h2 className="text-xl font-medium mb-4">Verify you are human</h2>
          
          <div className="flex items-center justify-between bg-white border border-gray-300 rounded p-4 h-16 cursor-pointer hover:bg-gray-50 transition-colors" onClick={status === 'waiting' ? handleVerify : undefined}>
            <div className="flex items-center gap-3">
              {status === 'waiting' && (
                <div className="w-6 h-6 border-2 border-gray-300 rounded bg-white" />
              )}
              {status === 'verifying' && (
                <Loader2 className="w-6 h-6 text-blue-600 animate-spin" />
              )}
              {status === 'success' && (
                <div className="w-6 h-6 rounded-full bg-green-500 flex items-center justify-center">
                   <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path></svg>
                </div>
              )}
              <span className="text-sm font-medium text-gray-700">Verify you are human</span>
            </div>
            <div className="flex flex-col items-end">
              <ShieldCheck className="w-8 h-8 text-gray-400" />
            </div>
          </div>
          <p className="text-xs text-gray-500 mt-2 text-center">
            This checks if the request is coming from a bot or a malicious script.
          </p>
        </div>

        <div className="text-center space-y-1">
            <p className="text-xs text-gray-400">Ray ID: <span className="font-mono">{rayId}</span></p>
            <p className="text-xs text-gray-400">Performance & security by Cloudflare</p>
        </div>
      </div>
    </div>
  );
};