import React, { useState } from 'react';
import { Card, Button, Input } from './ui';
import { AuthSubStage } from '../types';
import { Github, Mail, ArrowLeft, ShieldCheck, AlertCircle } from 'lucide-react';

interface Props {
  onAuthenticated: (email: string) => void;
}

export const AuthServer: React.FC<Props> = ({ onAuthenticated }) => {
  const [subStage, setSubStage] = useState<AuthSubStage>(AuthSubStage.LOGIN_IDENTIFY);
  const [isLoading, setIsLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [dob, setDob] = useState('');
  const [terms, setTerms] = useState(false);
  const [verifyCode, setVerifyCode] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  // Simulation State
  const [challengeKey, setChallengeKey] = useState('');
  const [error, setError] = useState<string | null>(null);

  // --- Handlers ---

  const handleCheckEmail = async () => {
    if (!email.includes('@')) {
      setError("Please enter a valid email address.");
      return;
    }
    setError(null);
    setIsLoading(true);
    
    // Simulate API /api/auth/check-email
    setTimeout(() => {
      setIsLoading(false);
      // Mock logic: "test@test.com" is an existing user
      if (email.toLowerCase() === 'test@test.com') {
        // User exists, give challenge token
        setChallengeKey('DP-' + Math.random().toString(36).substr(2, 9).toUpperCase());
        setSubStage(AuthSubStage.LOGIN_PASSWORD);
      } else {
        // User does not exist, usually we'd show error, but here we simulate the "Register" flow branching manually
        // In the prompt, if they clicked "Continue" on Login but are new, the prompt implies specific Register link usage.
        // But usually a smart flow detects it. We'll stick to the Prompt: "Clicking 'No account? Register' initiates..."
        // So if they are here, we assume they think they have an account.
        setError("Account not found. Please register.");
      }
    }, 800);
  };

  const handleLogin = async () => {
    setIsLoading(true);
    // Simulate /api/auth/login
    setTimeout(() => {
      setIsLoading(false);
      if (password === 'password') {
        onAuthenticated(email);
      } else {
        setError("Invalid credentials.");
      }
    }, 1000);
  };

  const handleRegisterStart = () => {
    setError(null);
    setSubStage(AuthSubStage.REGISTER_DETAILS);
  };

  const handleRegisterDetailsSubmit = () => {
    if(!email || !dob || !terms) return;
    setIsLoading(true);
    
    // Simulate /api/auth/check-email then /api/auth/register-start
    setTimeout(() => {
      setIsLoading(false);
      // Prompt: "Simulate email sent"
      setSubStage(AuthSubStage.REGISTER_VERIFY);
    }, 1200);
  };

  const handleVerifyCode = () => {
    setIsLoading(true);
    setError(null);
    // Simulate verification
    setTimeout(() => {
      setIsLoading(false);
      if (verifyCode === '123456') { // Mock code
         setSubStage(AuthSubStage.REGISTER_SET_PASSWORD);
      } else {
        setError("Invalid confirmation code (Use 123456)");
      }
    }, 800);
  };

  const handleRegisterFinalize = () => {
    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }
    if (password.length < 6) {
      setError("Password too short");
      return;
    }

    setIsLoading(true);
    // Simulate /api/auth/register-create
    setTimeout(() => {
      setIsLoading(false);
      onAuthenticated(email);
    }, 1500);
  };

  const handleSocialLogin = (provider: string) => {
    setIsLoading(true);
    // Simulate external redirect loop
    setTimeout(() => {
        setIsLoading(false);
        // For demo, we just log them in as a social user
        onAuthenticated(`user@${provider}.com`);
    }, 1500);
  };

  // --- Renders ---

  // 1. Initial Login View
  if (subStage === AuthSubStage.LOGIN_IDENTIFY) {
    return (
      <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
        <Card className="w-full max-w-md p-8">
          <div className="mb-6 text-center">
            <h2 className="text-2xl font-bold text-gray-900">Sign in</h2>
            <div className="mt-2 text-sm text-gray-600">
              <a href="#" onClick={(e) => { e.preventDefault(); handleRegisterStart(); }} className="font-medium text-blue-600 hover:text-blue-500">
                No account? Register
              </a>
            </div>
          </div>

          <div className="space-y-4">
             <div className="grid grid-cols-2 gap-3">
                <button onClick={() => handleSocialLogin('google')} className="flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg shadow-sm bg-white hover:bg-gray-50 transition text-sm font-medium text-gray-700">
                   <svg className="h-5 w-5 mr-2" aria-hidden="true" viewBox="0 0 24 24"><path d="M12.48 10.92v3.28h7.84c-.24 1.84-.853 3.187-1.787 4.133-1.147 1.147-2.933 2.4-6.053 2.4-4.827 0-8.6-3.893-8.6-8.72s3.773-8.72 8.6-8.72c2.6 0 4.507 1.027 5.907 2.347l2.307-2.307C18.747 1.44 16.133 0 12.48 0 5.867 0 .307 5.387.307 12s5.56 12 12.173 12c3.573 0 6.267-1.173 8.373-3.36 2.16-2.16 2.84-5.213 2.84-7.667 0-.76-.053-1.467-.173-2.053H12.48z" fill="currentColor" /></svg>
                   Google
                </button>
                <button onClick={() => handleSocialLogin('github')} className="flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg shadow-sm bg-white hover:bg-gray-50 transition text-sm font-medium text-gray-700">
                   <Github className="h-5 w-5 mr-2" />
                   GitHub
                </button>
             </div>

             <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300" />
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-white text-gray-500">OR</span>
                </div>
             </div>

             <form onSubmit={(e) => { e.preventDefault(); handleCheckEmail(); }}>
                <Input 
                    id="email" 
                    type="email" 
                    label="Email address" 
                    value={email} 
                    onChange={(e) => setEmail(e.target.value)} 
                    placeholder="name@example.com"
                    error={error || undefined}
                />
                <Button type="submit" className="mt-4" isLoading={isLoading}>Continue</Button>
             </form>
             
             <div className="text-xs text-gray-400 text-center mt-4">
                Protected by AuthServer Identity
             </div>
          </div>
        </Card>
      </div>
    );
  }

  // 2. Login Password View
  if (subStage === AuthSubStage.LOGIN_PASSWORD) {
     return (
      <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
        <Card className="w-full max-w-md p-8 relative">
          <button onClick={() => setSubStage(AuthSubStage.LOGIN_IDENTIFY)} className="absolute top-4 left-4 text-gray-400 hover:text-gray-600">
             <ArrowLeft className="w-5 h-5" />
          </button>
          
          <div className="mb-6 text-center">
            <h2 className="text-2xl font-bold text-gray-900">Welcome back</h2>
            <p className="text-gray-500 mt-1">{email}</p>
            <a href="#" onClick={(e) => { e.preventDefault(); handleRegisterStart(); }} className="text-xs text-blue-600 hover:text-blue-500 mt-1 inline-block">
                Switch to Registration
            </a>
          </div>

          <form onSubmit={(e) => { e.preventDefault(); handleLogin(); }} className="space-y-4">
             <Input 
                id="password" 
                type="password" 
                label="Password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                autoFocus
                error={error || undefined}
             />
             
             <div className="flex items-center justify-between text-sm">
                <span className="text-gray-400 text-xs font-mono bg-gray-100 px-2 py-1 rounded">
                    Key: {challengeKey.substring(0, 8)}...
                </span>
                <a href="#" className="text-blue-600 hover:text-blue-500">Forgot password?</a>
             </div>

             <Button type="submit" isLoading={isLoading}>Sign In</Button>
          </form>
        </Card>
      </div>
     );
  }

  // 3. Register Details
  if (subStage === AuthSubStage.REGISTER_DETAILS) {
      return (
      <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
        <Card className="w-full max-w-md p-8 relative">
           <button onClick={() => setSubStage(AuthSubStage.LOGIN_IDENTIFY)} className="absolute top-4 left-4 text-gray-400 hover:text-gray-600">
             <ArrowLeft className="w-5 h-5" />
          </button>
          
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Create account</h2>
            <p className="text-sm text-gray-500 mt-1">Step 1 of 3</p>
          </div>

          <form onSubmit={(e) => { e.preventDefault(); handleRegisterDetailsSubmit(); }} className="space-y-4">
             <Input 
                id="reg-email" 
                type="email" 
                label="Email address" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)} 
                required
             />
             
             <Input 
                id="reg-dob" 
                type="date" 
                label="Date of Birth" 
                value={dob} 
                onChange={(e) => setDob(e.target.value)} 
                required
             />

             <div className="flex items-start gap-3 pt-2">
                <input 
                    id="terms" 
                    type="checkbox" 
                    className="mt-1 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    checked={terms}
                    onChange={(e) => setTerms(e.target.checked)}
                />
                <label htmlFor="terms" className="text-sm text-gray-600">
                    I accept the Terms of Service and Privacy Policy.
                </label>
             </div>

             <Button type="submit" isLoading={isLoading} disabled={!email || !dob || !terms}>
                Continue
             </Button>
          </form>
        </Card>
      </div>
      );
  }

  // 4. Register Verification Code
  if (subStage === AuthSubStage.REGISTER_VERIFY) {
    return (
      <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
        <Card className="w-full max-w-md p-8">
          <div className="mb-6 text-center">
             <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 mb-4">
                <Mail className="h-6 w-6 text-blue-600" />
             </div>
             <h2 className="text-2xl font-bold text-gray-900">Check your email</h2>
             <p className="text-sm text-gray-500 mt-2">
                We sent a confirmation code to <span className="font-medium text-gray-900">{email}</span>.
             </p>
          </div>

          <div className="bg-amber-50 border border-amber-200 rounded-md p-3 mb-6 flex items-start gap-2">
             <AlertCircle className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
             <p className="text-xs text-amber-800">
                Demo: Enter code <strong>123456</strong> to proceed.
             </p>
          </div>

          <form onSubmit={(e) => { e.preventDefault(); handleVerifyCode(); }} className="space-y-4">
             <Input 
                id="code" 
                type="text" 
                label="Confirmation Code" 
                placeholder="123456"
                value={verifyCode}
                onChange={(e) => setVerifyCode(e.target.value)}
                error={error || undefined}
                className="text-center text-2xl tracking-widest font-mono"
                maxLength={6}
             />

             <Button type="submit" isLoading={isLoading}>Verify Email</Button>
          </form>
          
          <div className="mt-4 text-center">
            <button className="text-sm text-blue-600 hover:underline">Did not receive code? Re-send</button>
          </div>
        </Card>
      </div>
    );
  }

  // 5. Register Set Password
  if (subStage === AuthSubStage.REGISTER_SET_PASSWORD) {
      return (
      <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
        <Card className="w-full max-w-md p-8">
           <div className="mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Set Password</h2>
            <p className="text-sm text-gray-500 mt-1">{email}</p>
          </div>

           <form onSubmit={(e) => { e.preventDefault(); handleRegisterFinalize(); }} className="space-y-4">
             <Input 
                id="new-password" 
                type="password" 
                label="New Password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
             />
             <Input 
                id="confirm-password" 
                type="password" 
                label="Confirm Password" 
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                error={error || undefined}
             />

             <div className="bg-gray-50 p-3 rounded text-xs text-gray-500 space-y-1">
                <p className="flex items-center gap-2">
                    <ShieldCheck className="w-3 h-3" /> At least 6 characters
                </p>
                <p className="flex items-center gap-2">
                    <ShieldCheck className="w-3 h-3" /> Passwords match
                </p>
             </div>

             <Button type="submit" isLoading={isLoading}>Create Account</Button>
          </form>
        </Card>
      </div>
      );
  }

  return null;
};