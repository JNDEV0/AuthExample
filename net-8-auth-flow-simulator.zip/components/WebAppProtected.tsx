import React, { useState } from 'react';
import { Button, Card } from './ui';
import { UserSession } from '../types';
import { LogOut, Database, Shield, User } from 'lucide-react';

interface Props {
  session: UserSession;
  onLogout: () => void;
}

export const WebAppProtected: React.FC<Props> = ({ session, onLogout }) => {
  const [apiResponse, setApiResponse] = useState<string | null>(null);
  const [isLoadingApi, setIsLoadingApi] = useState(false);

  const handleCallApi = () => {
    setIsLoadingApi(true);
    setApiResponse(null);

    // Simulate calling WebApp backend -> Proxy -> ResourceApi
    setTimeout(() => {
        setApiResponse(JSON.stringify({
            message: "Secure data from ResourceApi",
            timestamp: new Date().toISOString(),
            user: session.email,
            scope: "api_access"
        }, null, 2));
        setIsLoadingApi(false);
    }, 1200);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <nav className="bg-white border-b border-slate-200 px-6 py-4 flex justify-between items-center shadow-sm">
        <div className="font-bold text-xl text-blue-700">WebApp <span className="text-gray-400 font-normal text-sm">| Account</span></div>
        <div className="flex items-center gap-4">
            <span className="text-sm text-gray-600">{session.email}</span>
            <Button variant="outline" className="!w-auto !py-1.5 text-sm" onClick={onLogout}>
                <LogOut className="w-4 h-4" /> Logout
            </Button>
        </div>
      </nav>

      <main className="max-w-5xl mx-auto p-8 grid grid-cols-1 md:grid-cols-3 gap-8">
        
        {/* Left: Identity Info */}
        <div className="md:col-span-1 space-y-6">
            <Card className="p-6">
                <div className="flex items-center gap-3 mb-4">
                    <User className="w-6 h-6 text-blue-600" />
                    <h3 className="font-semibold text-lg">Identity Claims</h3>
                </div>
                <div className="space-y-2 text-sm">
                    {session.claims.map((claim, idx) => (
                        <div key={idx} className="flex justify-between py-2 border-b border-gray-100 last:border-0">
                            <span className="text-gray-500">{claim.split(':')[0]}</span>
                            <span className="font-medium text-gray-800">{claim.split(':')[1]}</span>
                        </div>
                    ))}
                    <div className="flex justify-between py-2">
                         <span className="text-gray-500">token_type</span>
                         <span className="font-medium text-gray-800">Bearer</span>
                    </div>
                </div>
            </Card>

            <Card className="p-6 bg-blue-50 border-blue-100">
                 <div className="flex items-center gap-3 mb-2">
                    <Shield className="w-5 h-5 text-blue-600" />
                    <h3 className="font-semibold text-blue-900">Session Active</h3>
                </div>
                <p className="text-xs text-blue-700">
                    You are authenticated via OpenIddict. Refresh tokens are rotating in the background.
                </p>
            </Card>
        </div>

        {/* Right: API Interaction */}
        <div className="md:col-span-2">
            <Card className="p-6 h-full flex flex-col">
                <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                        <Database className="w-6 h-6 text-purple-600" />
                        <h3 className="font-semibold text-lg">Resource API</h3>
                    </div>
                    <Button 
                        className="!w-auto" 
                        onClick={handleCallApi} 
                        isLoading={isLoadingApi}
                    >
                        Call Protected Endpoint
                    </Button>
                </div>

                <div className="flex-1 bg-gray-900 rounded-lg p-4 font-mono text-sm text-green-400 overflow-auto">
                    <div className="flex items-center gap-2 text-gray-500 border-b border-gray-700 pb-2 mb-3">
                        <div className="w-3 h-3 rounded-full bg-red-500"></div>
                        <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                        <div className="w-3 h-3 rounded-full bg-green-500"></div>
                        <span className="ml-2">Console Output</span>
                    </div>
                    
                    {!apiResponse && !isLoadingApi && (
                        <span className="text-gray-500 opacity-50">Waiting for request... Click 'Call Protected Endpoint'</span>
                    )}
                    
                    {isLoadingApi && (
                         <div className="animate-pulse space-y-2">
                            <div className="h-4 bg-gray-700 rounded w-3/4"></div>
                            <div className="h-4 bg-gray-700 rounded w-1/2"></div>
                         </div>
                    )}

                    {apiResponse && (
                        <pre>{apiResponse}</pre>
                    )}
                </div>
                 <p className="text-xs text-gray-500 mt-4">
                    * Request proxy: WebApp (MVC) -&gt; GetTokenAsync -&gt; ResourceApi (Bearer Auth)
                 </p>
            </Card>
        </div>

      </main>
    </div>
  );
};