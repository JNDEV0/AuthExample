import React from 'react';
import { Button } from './ui';
import { Layout, Globe, Lock } from 'lucide-react';

interface Props {
  onLogin: () => void;
}

export const WebAppLanding: React.FC<Props> = ({ onLogin }) => {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Navbar */}
      <nav className="bg-white border-b border-slate-200 px-6 py-4 flex justify-between items-center">
        <div className="flex items-center gap-2 text-blue-700 font-bold text-xl">
          <Layout className="w-6 h-6" />
          <span>WebApp</span>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="!w-auto" onClick={onLogin}>Log in</Button>
          <Button className="!w-auto" onClick={onLogin}>Register</Button>
        </div>
      </nav>

      {/* Hero */}
      <main className="flex-1 flex flex-col items-center justify-center p-6 text-center max-w-4xl mx-auto space-y-8">
        <h1 className="text-5xl font-extrabold text-slate-900 leading-tight">
          Secure Authentication <br/>
          <span className="text-blue-600">Simulation Demo</span>
        </h1>
        <p className="text-lg text-slate-600 max-w-2xl">
          This prototype demonstrates a .NET 8 OIDC flow with Cloudflare interception, 
          multi-step registration, SRP6 simulation, and Claims-based authorization.
        </p>
        
        <div className="grid md:grid-cols-3 gap-6 mt-12 w-full">
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 text-left">
                <Globe className="w-8 h-8 text-orange-500 mb-4" />
                <h3 className="font-semibold text-slate-900">Cloudflare Fronted</h3>
                <p className="text-sm text-slate-500 mt-2">Simulates bot protection interception middleware before reaching AuthServer.</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 text-left">
                <Lock className="w-8 h-8 text-blue-500 mb-4" />
                <h3 className="font-semibold text-slate-900">OpenIddict Core</h3>
                <p className="text-sm text-slate-500 mt-2">Authorization Code Flow with PKCE. Stateless token handling.</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 text-left">
                <Layout className="w-8 h-8 text-purple-500 mb-4" />
                <h3 className="font-semibold text-slate-900">Interactive UI</h3>
                <p className="text-sm text-slate-500 mt-2">Progressive profiling and dynamic forms without full page reloads.</p>
            </div>
        </div>
      </main>
    </div>
  );
};